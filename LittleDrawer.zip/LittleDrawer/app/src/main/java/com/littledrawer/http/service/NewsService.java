package com.littledrawer.http.service;

import com.example.base.net.response.BaseResponse;
import com.littledrawer.http.api.Api;
import com.littledrawer.http.bean.News;

import java.util.Map;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

/**
 * @author 土小贵
 * @date 2019/4/17 23:09
 */
public interface NewsService {

    @POST(Api.NEWS_GET_NEWS_BY_ID)
    Call<BaseResponse<News>> getNewsById(@Body Map<String, String> map);

    @POST(Api.NEWS_GET_NEWS_BY_COLUMN)
    Call<BaseResponse<News>> getNewsByColumn(@Body Map<String, String> map);


    @POST(Api.NEWS_GET_NEWS_BY_USER_ID)
    Call<BaseResponse<News>> getNewsByUserId(@Body Map<String, String> map);


    @POST(Api.NEWS_GET_NEWS_RANDOM)
    Call<BaseResponse<News>> getNewsRandom(@Body Map<String, String> map);

    @POST(Api.NEWS_SEARCH_NEWS)
    Call<BaseResponse<News>> searchNews(@Body Map<String, String> map);

}
