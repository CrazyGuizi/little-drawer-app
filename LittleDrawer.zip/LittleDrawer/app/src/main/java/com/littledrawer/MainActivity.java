package com.littledrawer;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import com.littledrawer.R;
import com.littledrawer.common.BaseActivity;

import butterknife.BindView;

public class MainActivity extends BaseActivity {

    @BindView(R.id.tv_show)
    TextView mTextView;

    @Override
    public int getLayout() {
        return R.layout.activity_main;
    }

    @Override
    public void initWidget() {
        mTextView.setText("你好");
    }
}
