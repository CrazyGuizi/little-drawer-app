package com.littledrawer.event;

/**
 * EventBus事件基类
 *
 * @author 土小贵
 * @date 2019/4/18 11:39
 */
public class MessageEvent {
}
