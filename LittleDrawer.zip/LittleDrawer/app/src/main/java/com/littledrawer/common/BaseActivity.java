package com.littledrawer.common;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.littledrawer.event.MessageEvent;
import com.littledrawer.util.ActivityManager;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.lang.ref.WeakReference;

import butterknife.ButterKnife;

/**
 * @author 土小贵
 * @date 2019/4/18 11:00
 */
public abstract class BaseActivity extends AppCompatActivity {

    protected Activity mActivity =null;
    // 是否在前台
    protected boolean isActivity = false;
    private WeakReference<Activity> mWeakRefActivity = null;

    public abstract int getLayout();

    public void initWidget() {
    }

    public void initEvent() {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(getLayout());
        mActivity = this;
        mWeakRefActivity = new WeakReference<>(this);
        ActivityManager.add(mWeakRefActivity);
        ButterKnife.bind(this);
        EventBus.getDefault().register(this);
        initWidget();
        initEvent();
    }

    @Override
    protected void onResume() {
        super.onResume();
        isActivity = true;
    }

    @Override
    protected void onPause() {
        super.onPause();
        isActivity = false;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mActivity = null;
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    protected void onMessageEvent(MessageEvent event) {

    }
}
