package com.littledrawer.util;

/**
 * @author 土小贵
 * @date 2019/4/18 10:32
 */
public class Const {

    public static final String SHARED_PREFERENCES_NAME = "littleDrawer";
}
